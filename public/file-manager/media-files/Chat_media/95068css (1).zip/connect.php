<?php
$conn = mysqli_connect("localhost","trpenter_trpenterudb","Nu)O{Ea]0GiP","trpentertainment_washing_machine") or die('conncection failed to db');
?>