<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/disclamer.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100;0,300;0,400;1,500&family=Tiro+Bangla&display=swap" rel="stylesheet">
    
    <title>Instruction page</title>
</head>
<body>
   <section>
    <div class="main">
        <div class="Wrap_content">
          <h1>DISCLAIMER</h1>
                  <ol>
                      <li> Please note that capacity of Washing Machine is determined by “100% dry cotton clothes” (The Selected garment is adjusted to the parameters of the weight calculation)
                      </li>
                      <li> The displayed weight will have actual or +/- 10%  variation based on the type of garment chosen or different fabrics available in the market</li>
                      <li> To make the selection criteria easy and quick, the game is developed with the garments that are commonly used in Indian life styles. </li>
                      <li> The Website or any brand don’t own or reserve rights If there is any accuracy difference during load inputs</li>
                      <li> The website is only an Information/facilitation to make choice of purchase but not to Influence buyers decision</li>
                      <li> The Website is developed by 28th Avenue Media and Communications Private Limited for & on behalf of LG Electronics India Private Limited</li>
                      <li> Images used are representative in nature</li>
                     <li> LG Electronics India Private Limited does not make any authentication using this website game.</li>

                  </ol>
                  <center><a href="washing.php" style="color:white;text-decoration:none;"><button class="noselect">NEXT</button></a></center>
       </div>
    
</div>
    </section>
</body>
</html>