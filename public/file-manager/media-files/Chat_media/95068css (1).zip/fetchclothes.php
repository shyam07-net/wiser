<?php
session_start();
require('connect.php');
$user_mobile = $_SESSION['USER_MOBILE'];
    /*************************fetch particular clothes weight ****************************/
    $weight_qry = "SELECT * from user_machin_details WHERE user_mob='404'";
    $WghtResult = mysqli_query($conn,$weight_qry);
    $fetch_weight = mysqli_fetch_assoc($WghtResult);

    /****************to fetch particular user clothes qty ******************/

if(isset($_POST['data']))
{
    $section =  $_POST['data'];
    $qry = "SELECT * from clothes WHERE section='$section'";
    $run_qry = mysqli_query($conn,$qry);
    $html = '';

    $qty_qry = "SELECT * from user_machin_details WHERE user_mob='$user_mobile'";
    $QtyResult = mysqli_query($conn,$qty_qry);
    $data = mysqli_fetch_assoc($QtyResult);

    /*************************************************************/
      $html.=  '<div class="ImageList" id="Clothes"><div class="colImg">';
      while ($row = mysqli_fetch_assoc($run_qry))
     {
        $html .= 
                        '<div class="zphoto">
                            <div class="image"><a href=""><img src="images/'.$row['clothes_pic'].'" alt="profile picture" width="100px"
                                        height="100px"></a></div>
                            <div class="photo-name">'.$row['clothe_name'].'</div>
                            <!-- <button class="btnW">Submit</button> -->
                            <div class="number">
                                <span class="minus" onclick=operation("fetchclothes","'.$row['CID'].'","'.$row['clothes_id'].'","minus")>-</span>
                                <input type="text" value="'.$data[$row['CID']].'"  readonly/>
                                <span class="plus" onclick=operation("fetchclothes","'.$row['CID'].'","'.$row['clothes_id'].'","plus")>+</span>
                            </div>
                        </div>';
   }
   $html.= '</div></div>';
  $total_clothes_wght = $data['total_weight'];
  $SendArray  = array("html"=>$html,"weight"=>$total_clothes_wght);
  echo json_encode($SendArray);
}



if(isset($_POST['uid']))
{
  $unique_clothe_id = $_POST['uid'];   // colomun name in user machine and clothes table
  $clothe_id = $_POST['cid'];   // clothe id is clothe table unique id first column
 
 /************************Fetch All Row of Particular user and it  is unique for everyone  ***************/
  $old_data_qry = "SELECT * from user_machin_details WHERE user_mob='$user_mobile'";
  $run_old_data_qry = mysqli_query($conn,$old_data_qry);
  $old_data = mysqli_fetch_assoc($run_old_data_qry);
  $OldQty = $old_data[$unique_clothe_id];
  $OldTotalClothesWeight = $old_data['total_weight'];
/*********************************** Updation ********************************************/
  if($_POST['op']=='plus')   // increase value
  {
    $newQty = $OldQty+1;
    $AddedClothWeight = $fetch_weight[$unique_clothe_id];   // 
    $TotalClothWeight = $OldTotalClothesWeight+$AddedClothWeight;  // all weight 
  }if($_POST['op']=='minus')   // decrease value
  {
    if($OldQty==0)
    {
      $newQty = $OldQty;
      $TotalClothWeight = $OldTotalClothesWeight;
    }else{
      $newQty = $OldQty-1;
      $AddedClothWeight = $fetch_weight[$unique_clothe_id];   // 
      $TotalClothWeight = $OldTotalClothesWeight-$AddedClothWeight;  // all weight 
    }
  }
  $update_qty_for_user = "UPDATE user_machin_details SET $unique_clothe_id='$newQty',total_weight='$TotalClothWeight' WHERE user_mob='$user_mobile'";
  $run_update_query = mysqli_query($conn,$update_qty_for_user);
  if($run_update_query)
  {
     /*******************fetch clothes section  *********************************/
     $clothes_data_qry = "SELECT * from clothes where CID='$unique_clothe_id'";
     $qrun =  mysqli_query($conn,$clothes_data_qry);
     $clothes_details = mysqli_fetch_assoc($qrun);
     $section = $clothes_details['section'];
     $SendData = array("section"=>$section, "total_weight"=>$TotalClothWeight);
     echo json_encode($SendData);
  }else{
    echo 'failed';
  }

}

/**********************final list of clothes for recomendation *********************************/
if(isset($_POST['fcl']))
{
   $user_mobile = $_SESSION['USER_MOBILE'];
   $fcl_query = "SELECT * FROM user_machin_details WHERE user_mob='$user_mobile'";
   $run_fcl = mysqli_query($conn,$fcl_query);
   $fcl_data = mysqli_fetch_assoc($run_fcl);
   $ret = json_encode($fcl_data);
   echo $ret;
}


?>