<?php
require('connect.php');
session_unset();
session_destroy();
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title></title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="">
        <style>
body {
font-family: Times New Roman, Times, serif;Arial, Helvetica, sans-serif;
box-sizing: border-box;
/* background-image: url(images/background.png); */
background-color: #c5d4e8;
background-repeat: no-repeat;
background-size: cover;
}
.container {
    width: 27%;
    height: 100%;
    margin: auto;
    display: flex;
    justify-content: center;
    flex-direction: column;
}
.tara {
    padding: 35px;
    border-radius: 20px;
    background: white;
    padding: 35px;
    border-radius: 20px;
    border: 7px;
    padding: 50px;
    box-shadow: 23px 20px 6px -4px rgba(82,143,118,0.72);
-webkit-box-shadow: 23px 20px 6px -4px rgba(82,143,118,0.72);
-moz-box-shadow: 23px 20px 6px -4px rgba(82,143,118,0.72);
}
h1 {
    /* color: wheat; */
    color: #008080;
    text-align: center;
}
.formContent{
  padding-top: 121px;
}

/* button design */
 /* .signupbtn {
    width: 115px;
    height: auto;
    cursor: pointer;
    background: teal;
    border: 1px solid #91C9FF;
    outline: none;
    transition: 1s ease-in-out;
    text-align: center;
    padding-right: 20px;
    padding-left: 20px;
    padding-bottom: 20px;
}  */
 .signupbtn:hover {
  transition: 1s ease-in-out;
  background: #4F95DA;
} 

.signupbtn:hover svg {
  stroke-dashoffset: -480;
}
 .signupbtn span {
  color: white;
  font-size: 18px;
  font-weight: 100;
  font-weight: bold;
} 

button {
  padding: 1.3em 3em;
  font-size: 12px;
  text-transform: uppercase;
  letter-spacing: 2.5px;
  font-weight: 500;
  color: #000;
  background-color: #acc5cf;
  border: none;
  border-radius: 45px;
  box-shadow: 0px 8px 15px rgba(0, 0, 0, 0.1);
  transition: all 0.3s ease 0s;
  cursor: pointer;
  outline: none;
}



/* button design end */

/* Full-width input fields */
input[type=text] {
    width: 100%;
    padding-top: 15px;
    padding-bottom: 15px;
    margin: 5px 0 22px 0;
    display: inline-block;
    border: none;
    background: silver;
    border-radius: 20px;
    font-size: 15px;
    background-color: #edecec;
    padding-left: 10px;
}

input[type=text]:focus{
  background-color: #ddd;
  outline: none;
}

hr {
  border: 1px solid #f1f1f1;
  margin-bottom: 25px;
} 
/* Add padding to container elements */
.container {
  padding: 16px;
}

 .clearfix::after {
  content: "";
  clear: both;
  display: table;
}

/* Change styles for cancel button and signup button on extra small screens */
@media screen and (max-width: 767px) {
 /* .signupbtn {
     width: 100%;
  } */
  .container {
    width: 90%;
    height: 100%;
    margin: auto;
    display: flex;
    justify-content: center;
    flex-direction: column;
}
.formContent {
    padding-top: 40px;
}
input[type=text]{
  padding-top: 7px;
  padding-bottom: 10px;
}
}
</style>
    </head>
    <body>
<form action="" method="POST" style="border:1px solid #ccc"  class="formContent" >
  <div class="container">

    <div class="col-lg-8 m-auto d-block tara">
    <h1>SIGN UP</h1>
    <hr>
    <label for="name"><b>Name</b></label>
    <input type="text" placeholder="Enter Your name" name="name" required>

    <label for="mobile"><b>Mobile</b></label>
    <input type="text" placeholder="Enter your mobile" name="mobile" required>

    <label for="email"><b>Email</b></label>
    <input type="text" placeholder="Enter Email" name="email">

    <label for="city"><b>Location</b></label>
    <input type="text" placeholder="Enter your city" name="city" required>

    <label for="pincode"><b>PinCode</b></label>
    <input type="text" placeholder="Enter your pincode" name="pc" required>

<br/><br/>
    <div class="clearfix">
   <!-- <button class="signupbtn" name="submit" type="submit">Submit</button> -->
   <center><button class="signupbtn" name="submit" type="submit">SUBMIT
      </button></center>
      <!-- <button> Button
</button> -->
    </div>


    </div>

  </div>
</form>
    </body>
</html>


<?php 
if(isset($_POST['submit']))
{
$mobile = $conn->real_escape_string($_POST['mobile']);
$query_for_mobile = "SELECT * from customers where mobile='$mobile'";
$run_mobile_query = mysqli_query($conn,$query_for_mobile);
if(mysqli_num_rows($run_mobile_query)>0)
{
    echo 'mobile no already exists';
}else{
$name = $conn->real_escape_string($_POST['name']);
$email = $conn->real_escape_string($_POST['email']);
$city = $conn->real_escape_string($_POST['city']);
$pc = $conn->real_escape_string($_POST['pc']);
$sql= "INSERT INTO customers(user_name,mobile,email_id,location,pincode) VALUES('{$name}','{$mobile}','{$email}','{$city}','{$pc}')";
$result = mysqli_query($conn,$sql);
if($result)
{
$sql_for_washing_machine = "INSERT into user_machin_details(user_mob) VAlUES('{$mobile}')";
$run_query = mysqli_query($conn,$sql_for_washing_machine);

if ($run_query) {
    session_start();
    $_SESSION['USER_MOBILE'] = $mobile;
  ?> 
    <script> location.replace("instruction.php"); </script>
    <?php
  }
}else{
    echo 'Something went wrong please try again later';
}
}
}
?>