<?php
session_start();
require('connect.php');
if(!isset($_SESSION['USER_MOBILE']))
{
    header('location:index.php');
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/instruction.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100;0,300;0,400;1,500&family=Tiro+Bangla&display=swap" rel="stylesheet">
    <title>Intruction page</title>
</head>
<body>
    <section>
        <div class="main">
            <div class="Wrap_content">
              <h1>INSTRUCTIONS </h1>
                      <ol>
                          <h2>Get the right weight Washing Machine - Begin Now!</h2>
                          <p> 1. Select the clothes to add into Washing Machine as per your daily laundry requirements. </p>
                          <p> 2. Click "DONE" to know the final results. </p>
                         
                      </ol>
                      <center><a href="disclamer.php" style="color:white;text-decoration:none;"><button class="noselect">NEXT</button></a></center>
           </div>
        
    </div>
        </section>
</body>
</html>