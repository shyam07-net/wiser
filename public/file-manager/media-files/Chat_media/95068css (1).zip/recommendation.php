<?php
session_start();
require('connect.php');

if(!isset($_SESSION['USER_MOBILE']))
{
    header('location:index.php');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recommentation page</title>
</head>
<body>
    <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/recomnd.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100;0,300;0,400;1,500&family=Tiro+Bangla&display=swap" rel="stylesheet">
    
    <title>Recommendation page</title>
</head>
<body>
   <section>
    <div class="main">
        <div class="Wrap_content">
          <h1>OUR RECOMMENDATION <br>6 KG Washing Machine</h1>
          
          <div class="row">
              <div class="column">
                <div class="column" style="background-color:#b19e9e0f;">
                    <h2 style="background-color: black; color: white;">Summary<br>Total: 5 clothes</h2>
                    <br>
                    <div class="final-clothes-list">
                    <p>KIDS</p>
                    <p>Shirt: 1</p>
                    <p>Jeans: 2</p>
                    <p>Night suit: 1</p>
                    <p>Inner wear: 1</p>
                    </div>

                </div>
                <div class="column">
                    <!-- <h2>Column 2</h2> -->
                    <img class=" Wrap_img" src="./images/WM2.png">
                  
                  </div>
                 
                
                </div> 
       </div>
       <a href="thankyou.php" style="color:white;text-decoration:none;"><center><button class="noselect">Next</button></center></a>
    
</div>
</div>
<footer>Copyright @ 2020 The Wise Owl All Rights Reserved</footer>

</section>
    

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script>
    $(document).ready(function (){
    fetchClothesList();
    
        function fetchClothesList()
        {
            const fcl = "YES";
            $.ajax({
                type:"POST",
                url:"fetchclothes.php",
                data:{'fcl':fcl, },
            success: function(response) {
                console.log(response);
                alert(response);
            }
            });
        }
    });
        
        
    </script>
</body>
</html>