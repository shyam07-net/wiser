const body = document.querySelector('body'),
      sidebar = body.querySelector('nav'),
      toggle = body.querySelector(".toggle"),
      navLink = body.querySelector("nav-link");
      // navLinks = body.querySelector("sidebar open");
     
toggle.addEventListener("click" , () =>{
    sidebar.classList.toggle("close");
})
 
function OpenCategory(url,data)
{
document.getElementById('nav-bar').classList.add("close");
var id = data;
$.ajax({
 method:'post',
 url:url+'.php',
 data:{
   'data':data,
 },
 dataType: 'html',
 success:function(response){
var result = $.parseJSON(response);
$('.main-content').html(result.html);
var TotalWeight =result.weight;
var kg = TotalWeight/1000;
$('.total_w').val(kg+' Kg');
var weight = result.weight;
if(weight<=0)
{
 var degrees = 0;
}
else if(weight>0 && weight<=500)
{
  var degrees =18;
}else if(weight>500 && weight<=700)
{
var degrees = 27;
}else if(weight>700 && weight<=1000)  //1kg
{
  var degrees = 36;
}else if(weight>1000 && weight<=1500)  // 1.5 kg
{
  var degrees = 54;
}else if(weight>1500 && weight<=2000)  // 2kg
{
  var degrees = 72;
}else if(weight>2000 && weight<=2500)  // 2.5kg 
{
  var degrees = 90;
}else if(weight>2500 && weight<=3000)  //3kg
{
  var degrees = 108;
}else if(weight>3000 && weight<=3500)  //3.5 kg
{
  var degrees = 126;
}else if(weight>3500 && weight<=4000)  // 4 kg
{
var degrees = 144;
}else if(weight>4000 && weight<=4500)  // 4.5 kg
{
  var degrees = 162;
}else if(weight>4500 && weight<=5000)   //5kg
{
  var degrees = 180;
}else if(weight>5000 && weight<=5500) //5.5kg
{
  var degrees = 198;
}else if(weight>5500 && weight<=6000)  // 6 kg
{
  var degrees = 216;
}else if(weight>6000 && weight<=6500)  //6.5kg
{
  var degrees = 234;
}else if(weight>6500 && weight<=7000)  //7kg
{
  var degrees = 252;
}else if(weight>7000 && weight<=7500)   // 7.5kg
{
  var degrees = 270;
}else if(weight>7500 && weight<=8000)   // 8kg
{
  var degrees = 288;
}else if(weight>8000 && weight<=8500)   // 8.5kg
{
  var degrees = 306;
}else if(weight>8500 && weight<=9000)   // 9kg
{
  var degrees = 324;
}else if(weight>9000 && weight<=9500)   // 9.5kg
{
  var degrees = 342;
}
else{
  var degrees = 359;
  
}

document.getElementById('minuteHand'
).style.transform = 'rotate(' + degrees + 'deg)';


 }
  });
}


function operation(url,uid,cid,op)
{
$.ajax({
 method:'post',
 url:url+'.php',
 data:{
   'uid':uid,
   'cid':cid,
   'op':op,
 },
 // dataType: 'html',
 success:function(response){
  var res = $.parseJSON(response);
  if(response=='failed')
  {

  }else{
  OpenCategory('fetchclothes',res.section);
  var audio = new Audio("./music/insert.mp3");
  audio.play();
  }
 }
  });

}



