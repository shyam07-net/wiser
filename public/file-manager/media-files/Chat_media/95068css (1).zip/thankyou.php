<?php
session_start();
require('connect.php');
if(!isset($_SESSION['USER_MOBILE']))
{
    header('location:index.php');
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/thanku.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100;0,300;0,400;1,500&family=Tiro+Bangla&display=swap" rel="stylesheet">
    
    <title>Thank you page</title>
</head>
<body>
   <section>
    <div class="main">
        <div class="Wrap_content">
          <h2>Thank You for Visiting LG Best Shop</h2>
                  <ol>
                      <p> For more product information connect with our product consultants</p>
                      
                  </ol>
                  <center><a href="index.php" style="color:white;text-decoration:none;"><button class="noselect">PLAY AGAIN</button></a></center>
       </div>
    
</div>
    </section>
<?php  
session_unset();
session_destroy();
?>
</body>
</html>