-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jun 07, 2022 at 08:50 AM
-- Server version: 5.7.38
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `trpentertainment_washing_machine`
--

-- --------------------------------------------------------

--
-- Table structure for table `clothes`
--

CREATE TABLE `clothes` (
  `clothes_id` int(11) NOT NULL,
  `CID` varchar(10) NOT NULL,
  `clothe_name` varchar(100) NOT NULL,
  `clothe_weight` varchar(20) NOT NULL,
  `section` varchar(100) NOT NULL,
  `clothes_pic` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `clothes`
--

INSERT INTO `clothes` (`clothes_id`, `CID`, `clothe_name`, `clothe_weight`, `section`, `clothes_pic`) VALUES
(1, 'M1', 'Shirt', '180', 'Mens', 'Ms.jpg'),
(2, 'M2', 'T-shirt', '300', 'Mens', 'Mp.jpg'),
(3, 'M3', 'Pants', '700', 'Mens', 'Ml.jpg'),
(4, 'M4', 'Jeans', '800', 'Mens', 'Mj.jpg'),
(5, 'M5', 'Nightwear', '700', 'Mens', 'Mi.jpg'),
(6, 'W1', 'Top', '100', 'Women', 'ws.jpg'),
(7, 'W2', 'Jeans', '650', 'Women', 'wsal.jpg'),
(8, 'W3', 'Suit', '600', 'Women', 'wt.jpg'),
(9, 'W4', 'Saree', '600', 'Women', 'wj.jpg'),
(10, 'W5', 'Nightwear', '450', 'Women', 'wn.jpg'),
(11, 'K1', 'Shirt', '120', 'kids', 'k1.jpg'),
(12, 'K2', 'Jeans', '400', 'kids', 'k2.jpg'),
(13, 'K3', 'Short', '150', 'kids', 'k3.jpg'),
(14, 'K4', 'Dress', '200', 'kids', 'k4.jpg'),
(15, 'K5', 'Nightwear', '250', 'kids', 'k5.jpg'),
(16, 'H1', 'Towel', '500', 'hcare', 'hd.jpg'),
(17, 'H2', 'Bedsheet', '900', 'hcare', 'hk.jpg'),
(18, 'H3', 'Blanket', '4000', 'hcare', 'hp.jpg'),
(19, 'H4', 'Carpet', '3000', 'hcare', 'ht.jpg'),
(20, 'H5', 'Pillow Cover', '120', 'hcare', 'hb.jpg'),
(22, 'M6', 'Inner Wear', '100', 'Mens', 'Mn.jpg'),
(23, 'K6', 'Inner Wear', '40', 'Kids', 'ki.jpg'),
(24, 'W6', 'Inner Wear', '100', 'Women', 'wi.jpg'),
(25, 'H6', 'Curtains', '1000', 'hcare', 'hi.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `uid` int(11) NOT NULL,
  `user_name` varchar(100) DEFAULT NULL,
  `mobile` bigint(15) DEFAULT NULL,
  `email_id` varchar(100) DEFAULT NULL,
  `location` varchar(100) DEFAULT NULL,
  `pincode` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `user_machin_details`
--

CREATE TABLE `user_machin_details` (
  `id` int(11) NOT NULL,
  `user_mob` varchar(255) NOT NULL,
  `washing_machine_id` varchar(100) DEFAULT NULL,
  `M1` bigint(10) DEFAULT '0',
  `M2` bigint(10) DEFAULT '0',
  `M3` bigint(10) DEFAULT '0',
  `M4` bigint(10) DEFAULT '0',
  `M5` bigint(10) DEFAULT '0',
  `M6` int(10) DEFAULT '0',
  `W1` bigint(10) DEFAULT '0',
  `W2` bigint(10) DEFAULT '0',
  `W3` bigint(10) DEFAULT '0',
  `W4` bigint(10) DEFAULT '0',
  `W5` bigint(10) DEFAULT '0',
  `W6` int(10) DEFAULT '0',
  `K1` bigint(10) DEFAULT '0',
  `K2` bigint(10) DEFAULT '0',
  `K3` bigint(10) DEFAULT '0',
  `K4` bigint(10) DEFAULT '0',
  `K5` bigint(10) DEFAULT '0',
  `K6` int(10) DEFAULT '0',
  `H1` bigint(10) DEFAULT '0',
  `H2` bigint(10) DEFAULT '0',
  `H3` bigint(10) DEFAULT '0',
  `H4` bigint(10) DEFAULT '0',
  `H5` bigint(10) DEFAULT '0',
  `H6` int(10) DEFAULT '0',
  `total_weight` bigint(10) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user_machin_details`
--

INSERT INTO `user_machin_details` (`id`, `user_mob`, `washing_machine_id`, `M1`, `M2`, `M3`, `M4`, `M5`, `M6`, `W1`, `W2`, `W3`, `W4`, `W5`, `W6`, `K1`, `K2`, `K3`, `K4`, `K5`, `K6`, `H1`, `H2`, `H3`, `H4`, `H5`, `H6`, `total_weight`) VALUES
(1, '404', '404', 180, 300, 700, 800, 700, 100, 100, 650, 600, 600, 450, 100, 120, 400, 150, 200, 250, 40, 500, 900, 4000, 3000, 120, 1000, 15960);

-- --------------------------------------------------------

--
-- Table structure for table `washing_machines`
--

CREATE TABLE `washing_machines` (
  `wm_id` int(11) NOT NULL,
  `machine_name` varchar(100) NOT NULL,
  `size` varchar(20) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `washing_machines`
--

INSERT INTO `washing_machines` (`wm_id`, `machine_name`, `size`, `status`) VALUES
(1, '6 kg', '6000', 1),
(2, '8 kg', '8000', 1),
(3, '9 kg', '9000', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `clothes`
--
ALTER TABLE `clothes`
  ADD PRIMARY KEY (`clothes_id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`uid`);

--
-- Indexes for table `user_machin_details`
--
ALTER TABLE `user_machin_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `washing_machines`
--
ALTER TABLE `washing_machines`
  ADD PRIMARY KEY (`wm_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `clothes`
--
ALTER TABLE `clothes`
  MODIFY `clothes_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `uid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user_machin_details`
--
ALTER TABLE `user_machin_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=60;

--
-- AUTO_INCREMENT for table `washing_machines`
--
ALTER TABLE `washing_machines`
  MODIFY `wm_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
