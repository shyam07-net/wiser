<?php
session_start();
require('connect.php');
if(!isset($_SESSION['USER_MOBILE']))
{
    header('location:index.php');
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" 
    integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer"/>
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100;0,300;0,400;1,500&family=Tiro+Bangla&display=swap" rel="stylesheet">
    <!-- <link href='https://unpkg.com/boxicons@2.1.1/css/boxicons.min.css' rel='stylesheet'> -->
    <title>LG Washing Machine</title>
</head>
<body>
    <section class="SeC">
    <header>
            <H1 class="head">LG Washing Machine</H1>
        </header>
        <div class="row">
<!-- sidebar -->

<nav class="sidebar" id="nav-bar">
        <header>
            <!-- <div class="image-text">
                <span class="image">
                    <img src="" alt="">
                </span>
                <div class="text logo-text">
                    <span class="name">Click here</span>
                </div>
            </div> -->

            <i class='bx bx-chevron-right toggle'></i>
            <!-- <i class="fa-thin fa-arrow-right-long-to-line"></i> -->
        </header>

        <div class="menu-bar">
            <div class="menu">

                <ul class="menu-links" >
                    <li class="nav-link"  >
                        <a  onclick="OpenCategory('fetchclothes', 'kids')">
                        <i class="fa-solid fa-children" id="show_icon" ></i>
                            <span class="text nav-text">KIDS</span>  
                        </a>   
                    </li>
                    <!-- <hr class="line"> -->
                    </button>

                    <li class="nav-link">
                        <a  onclick="OpenCategory('fetchclothes', 'Mens');">
                        <i class="fa-solid fa-person-dress"></i>
                            <span class="text nav-text">MEN</span>
                        </a>
                    </li>
                    <!-- <hr class="line"> -->

                    <li class="nav-link">
                        <a  onclick="OpenCategory('fetchclothes', 'Women');">
                        <i class="fa-solid fa-person-dress"></i>
                            <span class="text nav-text">WOMEN</span> 
                        </a>
                    </li>
                    <!-- <hr class="line"> -->
                 

                    <li class="nav-link">
                        <a  onclick="OpenCategory('fetchclothes', 'hcare');">
                        <i class="fa-solid fa-house-user"></i>
                            <span class="text nav-text">HOME CARE</span>
                        </a>
                    </li>
                    <!-- <hr class="line1"> -->

                </ul>
            
            </div>
           
        </div>
    </nav>

    <section class="home">
        <div class="text"></div>
    </section>
            <!-- second washing machine and watch-->
            <div class="Wrappper">
                <input type="text" name="totalw" class="total_w" readonly value="0 Kg">
                 <a href="recommendation.php" style="color:white;text-decoration:none;"><button class="Wbutton">Done</button></a>
                <div class="WrapWatch">
                <div id="clock">
                    <div id="minuteHand"></div>
                </div>
                
             </div>
            <div class="WrapWash">
                <div class="img">
                    <img src="images/WM2.png" alt="hello">
                </div>
            </div>
            <!-- watch -->
            
        </div>

            <!-- new div -->
        <div class="main-content">
            
        </div>

        </div>
        <!-- washing machine for mobile -->
        <!-- <div class="washMobile">
            <div class="imgL">
                <img src="images/washing.jpg" alt="">
            </div>
        </div> -->
    </section>
     <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="script.js"></script>
</body>

</html>